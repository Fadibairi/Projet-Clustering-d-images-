# pipeline.py

import os
import numpy as np
import cv2
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (adjusted_rand_score, jaccard_score, homogeneity_score,
                             completeness_score, v_measure_score, silhouette_score,
                             adjusted_mutual_info_score)
from sklearn.pipeline import make_pipeline
import umap #on l'utilise au lieu de pca, pour rédurie la dimensionnalité.
import tensorflow as tf
from tensorflow.keras import layers, models


# ----- CONSTANTES -----
IMAGE_DIR = 'static/images/test' # Dossier contenant les images à traiter, à adapter ! 
MAX_FEATURES = 250
N_COMPONENTS = 10
K_FIXED = 20
OUTLIER_THRESHOLD = 0.15  #seuil pour éliminer les images aberrantes 
IMG_SIZE = 128
LATENT_DIM = 128  #Taille du vecteur latent de l'AE

results = []

# ----- UTILS -----
def load_images_from_folder(folder):
    """Charge les images depuis un dossier et ses sous-dossiers"""
    supported_formats = ('.jpg', '.jpeg', '.png')
    images = []
    filenames = []
    for root, _, files in os.walk(folder):
        for file in files:
            if file.lower().endswith(supported_formats):
                path = os.path.join(root, file)
                img = cv2.imread(path)
                if img is not None:
                    images.append(img)
                    filenames.append(os.path.relpath(path, folder))
    return images, filenames

def save_results_to_csv(results, filename='results.csv'):
    """Sauvegarde les résultats dans un fichier CSV"""
    results_df = pd.DataFrame(results)
    results_df.to_csv(filename, index=False)

def save_features_and_labels(features, labels, feature_file='reduced_features.npy', label_file='labels.npy'):
    """Sauvegarde les features et labels dans des fichiers numpy"""
    np.save(feature_file, features)
    np.save(label_file, labels)

def add_metrics_to_results(model_name, filenames, labels, features):
    """Calcule et ajoute les métriques d'évaluation aux résultats"""
    true_labels = [os.path.dirname(f).split(os.sep)[0] for f in filenames]
    le = LabelEncoder()
    y_true = le.fit_transform(true_labels)
    y_pred = labels

    metrics = {
        'Model': model_name,
        'Adjusted Rand Index': adjusted_rand_score(y_true, y_pred),
        'Jaccard Index': jaccard_score(y_true, y_pred, average='macro'),
        'Homogeneity': homogeneity_score(y_true, y_pred),
        'Completeness': completeness_score(y_true, y_pred),
        'V-measure': v_measure_score(y_true, y_pred),
        'Adjusted Mutual Information': adjusted_mutual_info_score(y_true, y_pred),
    }

    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    if n_clusters >= 2:
        metrics['Silhouette Score'] = silhouette_score(features, y_pred)
    else:
        metrics['Silhouette Score'] = np.nan

    results.append(metrics)
    return metrics  # Retourne les métriques pour un usage immédiat si besoin

# ----- FEATURES EXTRACTION -----
def extract_sift_features(images, max_features=MAX_FEATURES):
    """Extrait les features SIFT des images"""
    sift = cv2.SIFT_create(nfeatures=max_features)
    descriptors = []
    valid_images = []
    valid_indices = []
    vector_length = max_features * 128

    for i, img in enumerate(images):
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        kp, des = sift.detectAndCompute(gray, None)

        if des is not None and len(kp) >= 5:
            flat = des.flatten()
            if flat.shape[0] > vector_length:
                flat = flat[:vector_length]
            else:
                flat = np.pad(flat, (0, vector_length - flat.shape[0]))
            descriptors.append(flat)
            valid_images.append(img)
            valid_indices.append(i)

    return np.array(descriptors), valid_images, valid_indices

def extract_color_histograms(images):
    """Extrait les histogrammes de couleur des images"""
    histograms = []
    for img in images:
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV) # Convertir en HSV pour prendre en compte la luminosité et la saturation !!!
        hist = cv2.calcHist([hsv], [0, 1, 2], None, [8, 8, 8], [0, 180, 0, 256, 0, 256])
        hist = cv2.normalize(hist, hist).flatten()
        histograms.append(hist)
    return np.array(histograms) 

def build_autoencoder():
    """Construit un autoencodeur convolutif"""
    encoder_input = layers.Input(shape=(IMG_SIZE, IMG_SIZE, 3))
    x = layers.Conv2D(32, 3, activation='relu', padding='same')(encoder_input) #32 filtres qui détectent chacun des motifs différents !!!
    x = layers.MaxPooling2D()(x)  #Ici, on réduit la taille de l'image de moitié, on parcout par bloc de 4 et on garde que la valeur max !!!
    x = layers.Conv2D(64, 3, activation='relu', padding='same')(x) 
    x = layers.MaxPooling2D()(x)
    x = layers.Flatten()(x)
    encoded = layers.Dense(LATENT_DIM, activation='relu')(x) 

    x = layers.Dense((IMG_SIZE//4)*(IMG_SIZE//4)*64, activation='relu')(encoded)
    x = layers.Reshape((IMG_SIZE//4, IMG_SIZE//4, 64))(x)
    x = layers.Conv2DTranspose(64, 3, strides=2, activation='relu', padding='same')(x)
    x = layers.Conv2DTranspose(32, 3, strides=2, activation='relu', padding='same')(x)
    decoded = layers.Conv2D(3, 3, activation='sigmoid', padding='same')(x)

    autoencoder = models.Model(encoder_input, decoded)
    encoder = models.Model(encoder_input, encoded)
    autoencoder.compile(optimizer='adam', loss='mse')
    return autoencoder, encoder

def extract_autoencoder_features(images):
    """Extrait les features profondes avec l'autoencodeur"""
    resized = [cv2.resize(img, (IMG_SIZE, IMG_SIZE)) / 255.0 for img in images]
    X = np.array(resized, dtype=np.float32)
    autoencoder, encoder = build_autoencoder()
    autoencoder.fit(X, X, epochs=10, batch_size=32, verbose=0)
    features = encoder.predict(X, verbose=0)
    return features

# ----- OUTLIER DETECTION -----
def detect_outliers_isolation_forest(features, contamination=OUTLIER_THRESHOLD):
    """Détecte les outliers avec Isolation Forest"""
    iso = IsolationForest(contamination=contamination, random_state=42)
    preds = iso.fit_predict(features)
    mask = preds == 1
    return mask

# ----- DIMENSIONALITY REDUCTION -----
def apply_umap(features, n_components=N_COMPONENTS):
    """Applique UMAP pour la réduction de dimension"""
    reducer = make_pipeline(StandardScaler(), umap.UMAP(n_components=n_components, random_state=42))
    return reducer.fit_transform(features)

# ----- CLUSTERING EVALUATION -----
def evaluate_clustering(filenames, labels, features, title):
    """Évalue les performances du clustering et affiche les métriques"""
    true_labels = [os.path.dirname(f).split(os.sep)[0] for f in filenames]
    le = LabelEncoder()
    y_true = le.fit_transform(true_labels)
    y_pred = labels

    print(f"\n########## Métriques pour: {title}")
    print(f"Adjusted Rand Index: {adjusted_rand_score(y_true, y_pred):.4f}")
    print(f"Jaccard Index: {jaccard_score(y_true, y_pred, average='macro'):.4f}")
    print(f"Homogeneity: {homogeneity_score(y_true, y_pred):.4f}")
    print(f"Completeness: {completeness_score(y_true, y_pred):.4f}")
    print(f"V-measure: {v_measure_score(y_true, y_pred):.4f}")

    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    if n_clusters >= 2:
        print(f"Silhouette Score: {silhouette_score(features, y_pred):.4f}")
    else:
        print("Silhouette Score: non calculable (moins de 2 clusters)")

    print(f"Adjusted Mutual Information: {adjusted_mutual_info_score(y_true, y_pred):.4f}")

    # Ajoute les métriques aux résultats globaux
    add_metrics_to_results(title, filenames, labels, features)

# ----- PIPELINE PRINCIPAL -----
def run_pipeline():
    """Exécute le pipeline complet de traitement des images"""
    # Chargement des images
    images, filenames = load_images_from_folder(IMAGE_DIR)
    print(f"Images chargées: {len(images)}")

    # Extraction des features
    sift_features, valid_images, valid_indices = extract_sift_features(images)
    valid_filenames = [filenames[i] for i in valid_indices]
    print(f"Images conservées après SIFT: {len(valid_images)}")

    deep_features = extract_autoencoder_features(valid_images)
    color_features = extract_color_histograms(valid_images)

    # Combinaison des features
    combined_features = np.hstack((sift_features, deep_features, color_features))

    # Détection des outliers
    mask = detect_outliers_isolation_forest(combined_features)
    features = combined_features[mask]
    filtered_filenames = [f for i, f in enumerate(valid_filenames) if mask[i]]
    print(f"Images conservées après suppression des outliers: {len(features)}")

    # Réduction de dimension
    reduced_features = apply_umap(features)

    # Clustering avec différentes méthodes
    # KMeans avec k fixe
    kmeans = KMeans(n_clusters=K_FIXED, random_state=42)
    labels_kmeans = kmeans.fit_predict(reduced_features)
    evaluate_clustering(filtered_filenames, labels_kmeans, reduced_features, 
                       f"SIFT+AE+COLOR avec KMeans (k={K_FIXED})")

    # Agglomerative Clustering avec k fixe
    agglo = AgglomerativeClustering(n_clusters=K_FIXED)
    labels_agglo = agglo.fit_predict(reduced_features)
    evaluate_clustering(filtered_filenames, labels_agglo, reduced_features, 
                       f"SIFT+AE+COLOR avec Agglomerative (k={K_FIXED})")

    # DBSCAN avec différents paramètres eps
    for eps in [1.0, 1.5, 2.0, 2.5, 3.0]:
        dbscan = DBSCAN(eps=eps, min_samples=5)
        db_labels = dbscan.fit_predict(reduced_features)
        evaluate_clustering(filtered_filenames, db_labels, reduced_features, 
                          f"SIFT+AE+COLOR avec DBSCAN (eps={eps})")

    # Sauvegarde finale des résultats
    save_results_to_csv(results)
    save_features_and_labels(reduced_features, labels_kmeans)  # Exemple avec les labels KMeans

if __name__ == '__main__':
    run_pipeline()