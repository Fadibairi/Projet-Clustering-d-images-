# dashboard.py
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
from PIL import Image
import os
import seaborn as sns

# Configuration de la page
st.set_page_config(layout="wide", page_title="ClusterVision - Visualisation des Résultats de Clustering")

# Fonctions utilitaires
@st.cache_data
def load_data():
    """Charge les données nécessaires pour le dashboard"""
    try:
        metrics_df = pd.read_csv('results.csv')
        features = np.load('reduced_features.npy')
        labels = np.load('labels.npy')
        filenames = np.load('filtered_filenames.npy', allow_pickle=True)
        return metrics_df, features, labels, filenames
    except FileNotFoundError as e:
        st.error(f"Fichier manquant: {e}. Veuillez d'abord exécuter pipeline.py")
        st.stop()

def display_model_metrics(metrics_df):
    """Affiche les métriques des modèles sous forme de tableau et graphiques"""
    st.header("📊 Métriques de Performance par Modèle")
    
    # Tableau des métriques
    st.dataframe(metrics_df.style.highlight_max(axis=0, color='#90EE90'), 
                use_container_width=True)
    
    # Graphiques comparatifs
    metrics_to_plot = metrics_df.columns[1:]
    n_cols = 3
    n_rows = (len(metrics_to_plot) // n_cols) + 1
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, 5*n_rows))
    axes = axes.flatten()
    
    for i, metric in enumerate(metrics_to_plot):
        sns.barplot(data=metrics_df, x='Model', y=metric, ax=axes[i], palette='viridis')
        axes[i].set_title(metric)
        axes[i].tick_params(axis='x', rotation=45)
        axes[i].grid(True, alpha=0.3)
    
    # Cacher les axes vides
    for j in range(i+1, len(axes)):
        fig.delaxes(axes[j])
    
    plt.tight_layout()
    st.pyplot(fig)

def show_cluster_samples(image_dir, labels, filenames):
    st.header("🖼️ Galerie des Clusters")
    
    # Vérification des chemins
    if not os.path.exists(image_dir):
        st.error(f"Le dossier {image_dir} n'existe pas!")
        return

    cluster_dict = {}
    for label, filename in zip(labels, filenames):
        if label not in cluster_dict:
            cluster_dict[label] = []
        cluster_dict[label].append(filename)

    selected_cluster = st.selectbox(
        "Sélectionnez un cluster à visualiser",
        sorted(cluster_dict.keys()),
        format_func=lambda x: f"Cluster {x} - {len(cluster_dict[x])} images",
        index=0
    )

    st.subheader(f"Cluster {selected_cluster}")
    
    sample_files = np.random.choice(
        cluster_dict[selected_cluster], 
        size=min(5, len(cluster_dict[selected_cluster])), 
        replace=False
    )

    cols = st.columns(5)
    for col, img_file in zip(cols, sample_files):
        img_path = os.path.join(image_dir, img_file)
        if os.path.exists(img_path):
            try:
                img = Image.open(img_path)
                col.image(img, caption=os.path.basename(img_file), use_column_width=True)
            except Exception as e:
                col.error(f"Erreur: {str(e)}")
        else:
            col.error(f"Fichier introuvable: {img_path}")

def plot_3d_clusters(features, labels):
    """Visualisation 3D interactive des clusters avec Plotly"""
    st.header("🌌 Visualisation 3D des Clusters")
    
    # Réduction à 3 dimensions si nécessaire
    if features.shape[1] > 3:
        from sklearn.decomposition import PCA
        features_3d = PCA(n_components=3).fit_transform(features)
    else:
        features_3d = features
    
    # Création du DataFrame pour Plotly
    plot_df = pd.DataFrame(features_3d, columns=['Dim1', 'Dim2', 'Dim3'])
    plot_df['Cluster'] = labels.astype(str)
    
    # Définir les palettes de couleurs disponibles
    color_palettes = {
        'plotly': px.colors.qualitative.Plotly,
        'viridis': px.colors.sequential.Viridis,
        'plasma': px.colors.sequential.Plasma,
        'inferno': px.colors.sequential.Inferno,
        'rainbow': px.colors.sequential.Rainbow
    }
    
    # Paramètres de visualisation
    col1, col2 = st.columns(2)
    selected_palette = col1.selectbox(
        "Thème de couleur",
        options=list(color_palettes.keys()),
        index=1
    )
    
    point_size = col2.slider(
        "Taille des points",
        min_value=1, max_value=10, value=5
    )
    
    # Création du graphique 3D
    fig = px.scatter_3d(
        plot_df,
        x='Dim1',
        y='Dim2',
        z='Dim3',
        color='Cluster',
        color_discrete_sequence=color_palettes[selected_palette],
        hover_name='Cluster',
        title='Visualisation 3D des Clusters',
        height=800,
        opacity=0.8,
        symbol='Cluster'
    )
    
    fig.update_traces(
        marker=dict(size=point_size, line=dict(width=0.5, color='DarkSlateGrey')),
        selector=dict(mode='markers')
    )
    
    fig.update_layout(
        scene=dict(
            xaxis_title='Dimension 1',
            yaxis_title='Dimension 2',
            zaxis_title='Dimension 3'
        ),
        margin=dict(l=0, r=0, b=0, t=30)
    )
    
    st.plotly_chart(fig, use_container_width=True)

def main():
    """Fonction principale du dashboard"""
    st.title("🔍 ClusterVision - Analyse des Résultats de Clustering")
    st.markdown("""
    Ce dashboard interactif permet d'explorer les résultats du clustering d'images.
    """)
    
    # Chargement des données
    metrics_df, features, labels, filenames = load_data()
    
    # Section 1: Métriques de performance
    display_model_metrics(metrics_df)
    
    # Section 2: Visualisation 3D
    plot_3d_clusters(features, labels)
    
    # Section 3: Exemples par cluster
    show_cluster_samples('static/images/test', labels, filenames)
    
    # Pied de page
    st.markdown("---")
    st.markdown("""
    **📝 Note:** 
    - Pour des résultats optimaux, exécutez d'abord `pipeline.py` pour générer les données.
    - Assurez-vous que le fichier `filtered_filenames.npy` existe.
    """)

if __name__ == '__main__':
    main()